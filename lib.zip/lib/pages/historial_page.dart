import 'package:flutter/material.dart';

class HistorialPage extends StatelessWidget {
  const HistorialPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "📊 Aquí irá el historial de datos y gráficas.",
        style: TextStyle(color: Colors.white, fontSize: 18),
      ),
    );
  }
}
