import 'package:flutter/material.dart';
import '../widgets/sensor_card.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0E0E14),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: const [
              Text(
                "Dashboard IoT",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SensorGauge(
                    titulo: "Temperatura",
                    valor: 26.5,
                    unidad: "°C",
                    tipo: "temperatura",
                    maxValue: 50,
                  ),
                  SensorGauge(
                    titulo: "Humedad",
                    valor: 58,
                    unidad: "%",
                    tipo: "humedad",
                    maxValue: 100,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
